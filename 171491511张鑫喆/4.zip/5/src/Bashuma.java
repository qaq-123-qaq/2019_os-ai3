
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class Bashuma {

/**
 * @param args
 */
public static void main(String[] args) {
// TODO �Զ����ɷ������
new BaShuMaWin();
}

}
class BaShuMaWin extends JFrame implements MouseListener{
//�����Ÿ���ť
JButton button1,button2,button3,button4,button5,button6,button7,button8,button9;
JFrame frame=new JFrame("������С��Ϸ");
BaShuMaWin(){
JPanel contentPane=new JPanel();
frame.setContentPane(contentPane);
button1=new JButton();
button2=new JButton();
button3=new JButton();
button4=new JButton();
button5=new JButton();
button6=new JButton();
button7=new JButton();
button8=new JButton();
button9=new JButton();
button1.setText("1");
button2.setText("2");
button3.setText("3");
button4.setText("4");
button5.setText("5");
button6.setText("6");
button7.setText("7");
button8.setText("8");
button9.setText(null);
GridLayout gird=new GridLayout(3,3);//��frame��Ϊ3*3����״9С��
contentPane.setLayout(gird);
contentPane.add(button1);
contentPane.add(button2);
contentPane.add(button3);
contentPane.add(button4);
contentPane.add(button5);
contentPane.add(button6);
contentPane.add(button7);
contentPane.add(button8);
contentPane.add(button9);
frame.setBounds(300,300,400,400);
frame.setVisible(true);
validate();
frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
button1.addMouseListener(this);
button2.addMouseListener(this);
button3.addMouseListener(this);
    button4.addMouseListener(this);
button5.addMouseListener(this);
    button6.addMouseListener(this);
button7.addMouseListener(this);
button8.addMouseListener(this);
button9.addMouseListener(this);
}
public void  mousePressed(MouseEvent e){}
public void  mouseEntered(MouseEvent e){}
public void  mouseReleased(MouseEvent e){}
public void  mouseExited(MouseEvent e){}
public void  mouseClicked(MouseEvent e)
{
String s;
/*
if(button2.getText()==null)
{
s=button1.getText();
button2.setText(s);
button1.setText(null);
}
*/
if(button1.getText()==null)
{
s=button2.getText();
button1.setText(s);
button2.setText(null);
}
if(button1.getText()==null)
{
s=button4.getText();
button1.setText(s);
button4.setText(null);
}
if(button2.getText()==null)
{
s=button1.getText();
button2.setText(s);
button1.setText(null);
}
if(button2.getText()==null)
{
s=button5.getText();
button2.setText(s);
button5.setText(null);
}
if(button2.getText()==null)
{
s=button3.getText();
button2.setText(s);
button3.setText(null);
}
if(button3.getText()==null)
{
s=button2.getText();
button3.setText(s);
button2.setText(null);
}
if(button3.getText()==null)
{
s=button6.getText();
button3.setText(s);
button6.setText(null);
}
if(button4.getText()==null)
{
s=button1.getText();
button4.setText(s);
button1.setText(null);
}
if(button4.getText()==null)
{
s=button5.getText();
button4.setText(s);
button5.setText(null);
}
if(button4.getText()==null)
{
s=button7.getText();
button4.setText(s);
button7.setText(null);
}
if(button5.getText()==null)
{
s=button2.getText();
button5.setText(s);
button2.setText(null);
}

//�ƶ�5�Ű�ť
if(button5.getText()==null)
{
s=button4.getText();
button5.setText(s);
button4.setText(null);
}
if(button5.getText()==null)
{
s=button6.getText();
button5.setText(s);
button6.setText(null);
}
if(button5.getText()==null)
{
s=button8.getText();
button5.setText(s);
button8.setText(null);
}

//�ƶ�6�Ű�ť
if(button6.getText()==null)
{
s=button3.getText();
button6.setText(s);
button3.setText(null);
}
if(button6.getText()==null)
{
s=button5.getText();
button6.setText(s);
button5.setText(null);
}
if(button6.getText()==null)
{
s=button9.getText();
button6.setText(s);
button9.setText(null);
}

//�ƶ�7�Ű�ť
if(button7.getText()==null)
{
s=button4.getText();
button7.setText(s);
button4.setText(null);
}
if(button7.getText()==null)
{
s=button8.getText();
button7.setText(s);
button8.setText(null);
}

//�ƶ�8�Ű�ť
if(button8.getText()==null)
{
s=button7.getText();
button8.setText(s);
button7.setText(null);
}
if(button8.getText()==null)
{
s=button9.getText();
button8.setText(s);
button9.setText(null);
}
if(button8.getText()==null)
{
s=button5.getText();
button8.setText(s);
button5.setText(null);
}

//�ƶ�9�Ű�ť
if(button9.getText()==null)
{
s=button8.getText();
button9.setText(s);
button8.setText(null);
}
if(button9.getText()==null)
{
s=button6.getText();
button9.setText(s);
button6.setText(null);
}

}

}